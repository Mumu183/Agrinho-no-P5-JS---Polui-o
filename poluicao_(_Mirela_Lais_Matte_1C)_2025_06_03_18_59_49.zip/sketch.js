let pollutionLevel = 0;
let fish = [];
let trash = [];
const MIN_POLLUTION = 50;
let gameOver = false;

function setup() {
  createCanvas(800, 400);
  for (let i = 0; i < 10; i++) {
    fish.push(new Fish());
  }
}

function draw() {
  background(135, 206, 235);
  drawForest();
  drawRiver();
  drawTrash();
  updateFish();
  showPollutionMeter();

  if (!gameOver) {
    // Poluição aumenta até 100%
    if (pollutionLevel < 100 && frameCount % 30 === 0) {
      pollutionLevel += 2;
      let trashToAdd = pollutionLevel < 50 ? 2 : 4;
      for (let i = 0; i < trashToAdd; i++) {
        let trashType = random(1);
        if (trashType < 0.33) {
          trash.push(new Bag());
        } else if (trashType < 0.66) {
          trash.push(new Can());
        } else {
          trash.push(new Bottle());
        }
      }
    }

    if (pollutionLevel < 100 && random(1) < 0.02) {
      let trashType = random(1);
      if (trashType < 0.33) {
        trash.push(new Bag());
      } else if (trashType < 0.66) {
        trash.push(new Can());
      } else {
        trash.push(new Bottle());
      }
    }

    // Ajusta velocidade do lixo conforme poluição
    for (let t of trash) {
      t.speed = map(pollutionLevel, 0, 100, 0.5, 4);
    }
  } else {
    // Game over, lixo para de se mover
    for (let t of trash) {
      t.speed = 0;
    }
  }

  // Se poluição chegar a 100%, ativa game over
  if (pollutionLevel >= 100 && !gameOver) {
    pollutionLevel = 100;
    gameOver = true;
  }

  if (gameOver) {
    showFinalWarning();
  }
}

function mousePressed() {
  if (gameOver) return; // Não limpa lixo depois de game over

  for (let i = trash.length - 1; i >= 0; i--) {
    if (trash[i].isClicked(mouseX, mouseY)) {
      trash.splice(i, 1);
      // Poluição diminui, mas não abaixo do MIN_POLLUTION e só se não for game over
      pollutionLevel = max(MIN_POLLUTION, pollutionLevel - 7);
      break;
    }
  }
}

function drawForest() {
  for (let i = 0; i < width; i += 60) {
    fill(101, 67, 33);
    rect(i + 20, 200, 10, 50);
    fill(34, 139, 34);
    ellipse(i + 25, 190, 60, 60);
  }
}

function drawRiver() {
  noStroke();
  fill(70, 130, 180);
  rect(0, height / 2, width, height / 2);
}

function drawTrash() {
  for (let t of trash) {
    t.move();
    t.display();
  }
}

function updateFish() {
  for (let f of fish) {
    f.move();
    f.display();
  }

  if (pollutionLevel % 20 === 0 && fish.length > 2) {
    fish.pop();
  }
}

function showPollutionMeter() {
  fill(0);
  textSize(16);
  textAlign(LEFT, TOP);
  text("Nível de Poluição: " + pollutionLevel + "%", 10, 10);
}

function showFinalWarning() {
  fill(255, 0, 0, 220);
  rect(0, height / 2 + 40, width, 80); // faixa na parte central-inferior
  fill(255);
  textSize(24);
  textAlign(CENTER, CENTER);
  text("Cuidado com o lixo!", width / 2, height / 2 + 70);
  textSize(18);
  text("Ele polui o rio, a vida e a água que bebemos.", width / 2, height / 2 + 100);
}

class Fish {
  constructor() {
    this.x = random(width);
    this.y = random(height / 2 + 20, height - 20);
    this.speed = random(1, 3);
    this.color = color(255, 165, 0);
  }

  move() {
    this.x += this.speed;
    if (this.x > width) {
      this.x = 0;
    }
  }

  display() {
    fill(pollutionLevel > 50 ? 100 : this.color);
    ellipse(this.x, this.y, 20, 10);
    triangle(this.x - 10, this.y, this.x - 20, this.y - 5, this.x - 20, this.y + 5);
  }
}

class Trash {
  constructor() {
    this.x = random(width);
    this.y = random(height / 2, height / 2 + 50);
    this.speed = 0.5;
    this.size = 15;
  }

  move() {
    this.y += this.speed;
    if (this.y > height) {
      this.y = random(height / 2, height / 2 + 50);
      this.x = random(width);
    }
  }

  isClicked(px, py) {
    return px > this.x && px < this.x + this.size && py > this.y && py < this.y + this.size;
  }

  display() {
    fill(100);
    rect(this.x, this.y, this.size, this.size);
  }
}

class Bag extends Trash {
  constructor() {
    super();
    this.size = 16;
  }
  display() {
    fill(230, 230, 255);
    rect(this.x, this.y, this.size, this.size + 2, 3);
    stroke(0);
    line(this.x + 3, this.y, this.x + 3, this.y - 5);
    line(this.x + this.size - 4, this.y, this.x + this.size - 4, this.y - 5);
    noStroke();
  }
}

class Can extends Trash {
  constructor() {
    super();
    this.size = 14;
  }
  display() {
    fill(180);
    rect(this.x, this.y, this.size, this.size + 6, 2);
    fill(120);
    rect(this.x, this.y + this.size + 2, this.size, 3);
  }
}

class Bottle extends Trash {
  constructor() {
    super();
    this.size = 18;
  }
  display() {
    fill(0, 180, 0);
    rect(this.x + 4, this.y - 5, 5, 5);
    rect(this.x, this.y, this.size - 2, this.size + 4, 3);
  }
}